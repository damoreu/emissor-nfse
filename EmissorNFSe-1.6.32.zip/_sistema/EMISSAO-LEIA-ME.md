# Emissor de NFS-e (Emissor Nacional) — PROTÓTIPO

Aqui você **emite** notas digitando só o que muda. Pasta **independente** do
baixador (`_Sistema`): nada aqui mexe no download das notas, e vice-versa.
Toda a configuração fica no `emissao_config.txt` desta pasta (ambiente,
pasta dos certificados `.pfx` e pasta de saída).

## Como usar (dia a dia)

1. Dê 2 cliques em **`Emitir NFSe.bat`** — abre o formulário.
   - **1ª vez:** o programa pede pra você DEFINIR a senha de acesso. Nas
     próximas aberturas, ela é exigida. (Esqueceu? Apague `controle\acesso.json`
     e defina de novo.)
2. Escolha o **emitente** (os dados fiscais fixos vêm do `cadastro_emitentes.xlsx`).
   - Abaixo do nome aparece o **regime** (Simples MEI/ME-EPP ou, em vermelho,
     NÃO optante).
   - **Se for optante do Simples**, surge o campo **"Alíq. Simples (%)"**, já
     preenchido com o último valor usado nessa empresa (ou o do cadastro,
     `P_TOT_TRIB_SN`). A alíquota efetiva do Simples muda **mês a mês** — informe
     aqui a do mês, e o que você digitar fica lembrado para a próxima nota da
     mesma empresa. Empresa não-optante não vê esse campo.
3. Digite só o que muda: **tomador, descrição do serviço e valor**.
   - Tomador já usado antes? Digite o CNPJ e clique **buscar** — o resto autopreenche.
   - **Cidade é pelo nome** (ex.: `chapecó`, `porto alegre`) — o código IBGE é
     resolvido sozinho e aparece em verde embaixo do campo. Se o nome existir em
     mais de um estado, acrescente a UF (ex.: `santa luzia MG`).
4. Precisa de retenção, desconto, outra competência ou outro município de
   prestação? Clique em **"▸ Mais opções"**:
   - **ISS retido pelo tomador** — marque e informe a alíquota do ISS (%)
     (ou deixe preenchida a coluna ALIQ_ISS do cadastro). Mínimo 1,8%.
   - **Retenções federais** — marque o que é retido e clique **calcular**
     (alíquotas padrão: PIS 0,65 / COFINS 3 / CSLL 1 / IRRF 1,5 / INSS 11%),
     ou digite os valores. Pela NT 007/2026, o XML soma PIS+COFINS+CSLL
     retidos em `vRetCSLL` e informa o tipo (`tpRetPisCofins` 0/3-9) sozinho.
   - **PIS/COFINS PRÓPRIOS** — para empresa que só DESTACA (apuração
     própria, sem retenção; ex.: regime geral). Vai em `vPis`/`vCofins` no
     XML e sai no PDF como "Débito Apuração Própria". Alíquotas por empresa
     nas colunas ALIQ_PIS/ALIQ_COFINS do cadastro (vazio = 0,65 / 3,00).
   - **Descontos** (incondicionado reduz a base) e **dedução** da base.
   - **OBRA** (construção civil) — código CNO/CEI ou inscrição imobiliária mais
     o endereço. Obrigatório nos subitens 07.02, 07.04, 07.05, 07.06, 07.07,
     07.08, 07.17 e 07.19; sem ele a SEFIN recusa (E0370).
   - **EVENTO** (feiras, shows, congressos) — descrição, data inicial e data
     final. **Obrigatório em toda atividade do item 12** da lista de serviços
     (12.01 a 12.17: teatro, cinema, circo, parques, boates, shows, feiras,
     bilhar, boliche, corridas, competições, música, produção de eventos,
     blocos, exibições e recreação) e **proibido fora dele** — só o 99.01.01
     aceita sem exigir. O aviso ao lado do bloco diz qual é o caso da atividade
     escolhida. Deixe o *Identificador* em branco e ele sai com o nome do
     evento, que é o que o portal do Emissor Nacional faz; preencha o CEP só se
     o município pedir o endereço (o CEP tem de ser o do local da prestação).
   - **Local de prestação** (cidade por nome). A competência fica no topo.
5. Clique **EMITIR NOTA**. O XML e o PDF (DANFSe) são salvos em
   `NOTAS EMITIDAS\MM.AAAA\` (dentro desta pasta; mude em `emissao_config.txt`).

## Menu — o que dá pra fazer além de emitir

Barra de menu no topo da janela:

**Notas**
- **Notas emitidas / histórico…** — lista todas as notas já emitidas (data,
  emitente, tomador, valor, situação). **Duplo-clique abre o PDF**; dá também
  para abrir o XML e copiar a chave de acesso.
- **Repetir última nota deste emitente** — recarrega tomador, descrição e valor
  da última nota do emitente selecionado. Ideal para cobrança recorrente:
  revise o valor e emita.
- **Cancelar uma nota…** — escolhe uma nota emitida (ou cola a chave), o motivo
  (Erro na emissão / Serviço não prestado / Outros) e uma **justificativa
  (obrigatória, mín. 15 caracteres)**, e envia o evento de cancelamento
  **101101** assinado. **Cancelamento é definitivo** e sujeito ao prazo do
  município — em produção, confirme com cuidado.

**Ferramentas**
- **Buscar cliente por nome…** — acha o tomador no cache pelo nome (não precisa
  decorar CNPJ) e joga no formulário.
- **Relatório de faturamento…** — total emitido no ano por emitente. Para **MEI**
  mostra o quanto já usou do **teto anual de R$ 81.000** (verde/azul/vermelho) e
  avisa se estourou.
- **Fazer backup agora** — gera um `.zip` datado em `backups\` com as notas
  emitidas e o controle (numeração, histórico e cache). A senha do programa
  **não** entra no backup.

**Ajuda**
- **Validade do certificado** — mostra quando o A1 do emitente vence. Na
  abertura, o programa avisa sozinho se faltarem **30 dias ou menos** (ou se já
  venceu).
- **Procurar atualizações…** — baixa e instala a versão nova (o programa fecha e
  abre sozinho, já atualizado). Seus cadastros, certificados, notas emitidas e
  configurações **não** são tocados. Quando sai uma versão, o próprio programa
  avisa na abertura — não precisa ficar procurando.

## Autopreencher tomador NOVO pela Receita

No bloco **Tomador**, digite o CNPJ e clique **consultar CNPJ**: nome, endereço
e cidade vêm da base pública (BrasilAPI) — precisa de internet. Sem conexão ou
CNPJ inexistente, é só preencher à mão como antes. O **buscar** continua puxando
do cache local (clientes já usados/importados).

## Outras facilidades

- **Valor** ganha máscara automática (`1.234,56`) ao sair do campo.
- **CNPJ/CPF do tomador** é conferido pelo dígito verificador antes de emitir —
  se estiver errado, o programa avisa (dá pra emitir mesmo assim se insistir).
- **Descrições favoritas**: escreveu uma descrição que se repete? Clique
  **★ salvar**; depois use **favoritas ▾** para reaproveitar num clique.
- **Erros da API** vêm com uma dica em português (`→ ...`) explicando o que fazer.

## Cadastrar um cliente (tomador)

**Um cliente só, na hora:** clique em **Cadastrar cliente** na barra lateral (ou
**Ferramentas > Cadastrar cliente**, ou **Ctrl+T**).

- cliente com **CNPJ** → digite o CNPJ e saia do campo (ou clique **consultar
  CNPJ**): razão social, endereço, cidade, e-mail e telefone se preenchem pela
  base da Receita, **na tela**, antes de salvar. Confira e salve;
- cliente com **CPF** → informe o nome e o **CEP** e clique **buscar CEP**: vêm
  rua, bairro e cidade (não existe base pública de endereço por CPF). Sobra o
  número e o complemento.

São as mesmas duas buscas da tela da nota, com as mesmas regras: a busca
automática (ao sair do campo) só completa o que está em branco; o botão traz o
cadastro da base por cima — é assim que se atualiza um endereço velho. Cliente que
já está na agenda abre com o cadastro dele: **salvar atualiza, não duplica**.

O cliente entra na carteira da **empresa selecionada**, então já aparece no
**+ Adicionar tomador** da Emissão em lote e na busca por nome (**Ctrl+F**). Use
**salvar e cadastrar outro** para emendar vários. Faltando endereço, a tela diz o
que falta e continua aberta.

Cadastrar antes não é obrigatório: **toda nota emitida guarda o tomador sozinha**.
A tela serve para quem quer montar a carteira antes de emitir — e para corrigir um
endereço que a Receita devolve errado, sem precisar emitir nota para isso.

## Importar seus clientes (autopreenchimento desde o 1º dia)

Para a carteira inteira de uma vez: use
**`AJUDA\MODELO-IMPORTACAO-CLIENTES.xlsx`** e importe pelo menu
**Ferramentas > Importar clientes** ou pelo **+ Importar planilha** da Emissão em
lote.

**Você preenche só o que ninguém tem como descobrir:**

- cliente com **CNPJ** → *só o CNPJ*. Razão social, endereço, bairro, cidade e
  CEP vêm da base pública da Receita na hora da importação;
- cliente com **CPF** → nome, **CEP**, número e complemento. Do CEP saem rua,
  bairro e cidade (não existe base de endereço por CPF);
- o **complemento** (apto/sala/bloco) é sempre seu — nenhuma base pública tem.

As colunas cinza do modelo são opcionais: deixe em branco e o sistema preenche.
Se você preencher, **o que você escreveu manda** — o online só completa o vazio.
As colunas podem estar em qualquer ordem e com nomes comuns (Razão Social,
CPF/CNPJ, Município, UF...). Cliente que ficar sem endereço completo é listado no
fim da importação, para conferir na 1ª nota.

**Sem planilha nenhuma:** na Emissão em lote, **+ Colar lista** aceita um CNPJ
por linha (ou várias colunas colhidas do Excel com Ctrl+C) e faz o mesmo.

Precisa de internet para o autopreenchimento. Sem internet, a importação avisa e
entra só com o que a planilha traz — importar de novo depois consulta apenas o
que faltou (nada é duplicado nem apagado).

Pela linha de comando:

```
python importar_clientes.py "C:\caminho\clientes.xlsx"
```

(`--offline` importa sem consultar as bases públicas.)

## Ambiente (IMPORTANTE)

O arquivo **`emissao_config.txt`** controla o ambiente:

- `ambiente = restrita` → **homologação**. NÃO gera nota real. (padrão)
- `ambiente = producao` → **EMITE NOTA DE VERDADE** (gera obrigação fiscal).

O formulário mostra o ambiente num **banner** (verde = restrita, vermelho = produção)
e pede confirmação extra antes de emitir em produção.

> Sempre teste um cliente novo na **restrita** antes de virar pra produção.

## Cadastrar um novo emitente

Abra **`cadastro_emitentes.xlsx`** e preencha uma linha nova. A aba **AJUDA**
explica cada coluna. Campos essenciais:

- `CNPJ`, `SENHA` (a mesma senha do certificado, igual ao CERTIFICADOS.xlsx)
- `COD_MUN` (código IBGE do município do emitente, 7 dígitos)
- `OP_SIMP_NAC` (1=Não, 2=MEI, 3=ME/EPP) e, se optante, `REG_AP_TRIB_SN`
- `SERIE` (uma série sua para a API — ex. `900`; **diferente** da série do portal web)
- `C_TRIB_NAC` (código de tributação do serviço) e `P_TOT_TRIB_SN` (% Simples —
  valor padrão; dá pra sobrescrever por nota no campo "Alíq. Simples (%)" do
  formulário)

Pré-requisito: o `.pfx` do emitente tem que estar na pasta de certificados
definida no `emissao_config.txt` (`pasta_certificados`).

## Numeração das notas (nDPS)

Controlada sozinha em `controle\ndps.json`, **por emitente + série + ambiente**.
O número só avança **depois** que a nota é aceita — se cair a internet no meio,
nenhum número é perdido (mesma lógica do NSU do baixador). Contadores de
restrita e produção são separados: testar não queima número de produção.

## Testar sem interface

`python teste_emissao.py` roda um self-test **offline** (monta o DPS, assina e
reverifica) sem enviar nada à API.

## Arquivos

| Arquivo | O que é |
|---|---|
| `emissor.pyw` | Formulário (interface) |
| `emitir_nfse.py` | Motor: monta DPS, controla nDPS, envia, salva |
| `assinatura_nfse.py` | Assinatura digital (XMLDSig) do DPS e do evento de cancelamento |
| `certificados.py` | Localiza o .pfx pelo CNPJ (cópia local, independente do baixador) |
| `consulta_cnpj.py` | Consulta CNPJ na base pública p/ autopreencher tomador |
| `danfse_oficial.py` | Gera o PDF da nota (cópia local) |
| `cadastro_emitentes.xlsx` | Dados fiscais fixos por emitente |
| `emissao_config.txt` | Ambiente + pastas (certificados e saída) |
| `controle\ndps.json` | Numeração das notas |
| `controle\tomadores.json` | Cache de tomadores (autopreenche) |
| `controle\historico.json` | Índice das notas emitidas (histórico/relatório/repetir) |
| `controle\descricoes.json` | Descrições de serviço favoritas |
| `backups\` | Zips de backup gerados sob demanda |
